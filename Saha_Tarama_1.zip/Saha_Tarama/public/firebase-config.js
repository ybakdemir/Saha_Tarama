const firebaseConfig = {
  apiKey: "BURAYA_FIREBASE_API_KEY",
  authDomain: "sahatarama-33b52.firebaseapp.com",
  projectId: "sahatarama-33b52",
  storageBucket: "sahatarama-33b52.appspot.com",
  messagingSenderId: "BURAYA_MESSAGING_SENDER_ID",
  appId: "BURAYA_APP_ID"
};

export default firebaseConfig;
