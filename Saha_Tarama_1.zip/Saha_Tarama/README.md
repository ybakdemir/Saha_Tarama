# OKM Saha Analiz — Conrad X3 Ultra

Yeraltı görüntüleme verileri için yapay zeka destekli analiz uygulaması.

**Cihaz:** Conrad X3 Ultra  
**Sensör:** 4× FLC100 (dikey + yatay aparat)  
**Yazılım:** OKM + Visualizer 3D

---

## Kurulum

### 1. Firebase Ayarları

Firebase Console → SahaTarama projesi → Proje Ayarları → Web uygulaması ekle:

`public/index.html` dosyasında bu satırları Firebase config'iniz ile doldurun:
```js
apiKey: "BURAYA_FIREBASE_API_KEY",
messagingSenderId: "BURAYA_MESSAGING_SENDER_ID",
appId: "BURAYA_APP_ID"
```

Firebase Console → Authentication → Sign-in method → Email/Password → Etkinleştir

Firebase Console → Firestore Database → Oluştur → Test modunda başlat

### 2. Vercel Ortam Değişkeni

Vercel Dashboard → Projeniz → Settings → Environment Variables:

```
ANTHROPIC_API_KEY = sk-ant-...buraya-api-keyinizi-girin...
```

### 3. GitHub'a Push

```bash
git init
git add .
git commit -m "ilk commit"
git remote add origin https://github.com/ybakdemir/Saha_Tarama.git
git branch -M main
git push -u origin main
```

### 4. Vercel Deploy

Vercel Dashboard → New Project → GitHub'dan Saha_Tarama reposunu seç → Deploy

---

## Proje Yapısı

```
Saha_Tarama/
├── api/
│   └── analyze.js        ← Vercel serverless (Anthropic proxy)
├── public/
│   └── index.html        ← Ana uygulama
├── vercel.json
├── package.json
└── .gitignore
```

---

## Özellikler

- Dikey (Magnetometre) ve Yatay (Gradyometre) aparat desteği
- 4× FLC100 sensör dizilimi analizi
- Tarama parametreleri: alan, darbe sayısı, sensör yüksekliği
- Kalibrasyon güvenilirlik değerlendirmesi
- Anomali tespiti: Metal, Boşluk, Mineral, Kaya, Toprak
- Firebase ile analiz geçmişi kaydetme
- Kullanıcı girişi (Email/Password)
